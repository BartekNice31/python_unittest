class SimpleMathCalculator:

    def add(self, x, y):
        return x + y

    def sub(self, x, y):
        return x - y

    def mul(self, x, y):
        return x * y

    def true_div(self, x, y):
        return x / y

    def floor_div(self, x, y):
        return x // y