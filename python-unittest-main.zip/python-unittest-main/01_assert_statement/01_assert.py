condition = True
# if not condition:
#     raise AssertionError('Assertion message.')

assert condition, 'Assertion message.'


