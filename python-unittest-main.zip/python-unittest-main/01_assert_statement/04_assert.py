def area(width, height):
    """The function returns the area of the rectangle."""
    return width * height + 1

assert area(4, 5) == 20
