def calc_tax(amount, tax_rate):
    return amount * (tax_rate / 100.0)

