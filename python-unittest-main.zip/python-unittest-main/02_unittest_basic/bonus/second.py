print(__name__)
print('[INFO] Skrypt second.')

import first
print(first.__name__)