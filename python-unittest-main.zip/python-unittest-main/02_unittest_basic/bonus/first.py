print(__name__)
print('[INFO] Skrypt first.')

if __name__ == '__main__':
    print('Skrypt first.')